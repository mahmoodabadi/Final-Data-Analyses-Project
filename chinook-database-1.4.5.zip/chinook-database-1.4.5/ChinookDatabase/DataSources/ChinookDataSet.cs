﻿namespace ChinookDatabase.DataSources
{

    partial class ChinookDataSet
    {
    }
}
